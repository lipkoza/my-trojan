InfiniteİnvertCircles.exe
by me press esc close bye