Everything You Know Is Wrong.exe
by @lipkoza my new malware this c++ and hsl playload bye