  OOOOO   CCCCC   TTTTT   AAAAA   CCCCC   H   H   L       OOOOO   RRRRR
 O     O C     C    T    A     A C     C  H   H   L      O     O  R    R
 O     O C          T    AAAAAAA C        HHHHH   L      O     O  RRRRR
 O     O C     C    T    A     A C     C  H   H   L      O     O  R   R
  OOOOO   CCCCC     T    A     A  CCCCC   H   H   LLLLL   OOOOO   R    R

        CCCCC   Y   Y   CCCCC   L       OOOOO
       C     C   Y Y   C     C  L      O     O
       C          Y    C        L      O     O
       C     C    Y    C     C  L      O     O
        CCCCC     Y     CCCCC   LLLLL   OOOOO

  H   H   EEEEE   X   X   AAAAA   N   N   EEEEE
  H   H   E        X X   A     A  NN  N   E
  HHHHH   EEEE      X    AAAAAAA  N N N   EEEE
  H   H   E        X X   A     A  N  NN   E
  H   H   EEEEE   X   X  A     A  N   N   EEEEE.exe
by @lipkoza my new malware bye.