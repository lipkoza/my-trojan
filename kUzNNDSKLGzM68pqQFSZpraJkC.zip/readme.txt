kUzNNDSKLGzM68pqQFSZpraJkC.exe
by @lipkoza my new malware bye.