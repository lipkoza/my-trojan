polystonium.exe
by @lipkoza my first real gdi virus bye.