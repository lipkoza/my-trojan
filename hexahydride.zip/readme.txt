H       H EEEEEEE X     X     A     H      H  Y   Y  DD    RR   İ DD   EEEEEEE   EEEEEEE X    X EEEEEEE
H       H E        X   X     A A    H      H   Y Y   D D   R R    D D  E         E        X  X  E
HHHHHHHHH EEEEEEE   X X     AAAAA   HHHHHHHH    Y    D  D  RR   İ D  D EEEEEEE   EEEEEEE   XX   EEEEEEE
H       H E        X   X   A     A  H      H    Y    D D   R R  İ D D  E         E        X  X  E
H       H EEEEEEE X     X A       A H      H    Y    DD    R  R İ DD   EEEEEEE . EEEEEEE X    X EEEEEEE
by @lipkoza my new malware And this is my fifth piece of malware bye.