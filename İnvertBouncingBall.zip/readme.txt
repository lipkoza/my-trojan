İnvertBouncingBall.exe
by @lipkoza press esc close bye