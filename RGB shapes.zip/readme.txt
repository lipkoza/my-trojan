RGB shapes.exe
by @lipkoza press esc close bye